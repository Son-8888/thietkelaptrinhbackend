﻿Console.OutputEncoding = System.Text.Encoding.UTF8;

////bài 1
//string? ten;
//int tuoi;
// Console.Write("nhap ten: ");
//ten = Console.ReadLine();
//Console.Write("Nhap tuoi: ");
//tuoi = int.Parse(Console.ReadLine() ?? "0");
// Console.WriteLine($"xin chao {ten}, ban {tuoi} tuoi");
////bai 2
//float rong, dai;

//try
//    Console.Write("nhap chieu rong: ");
//    rong = float.Parse(Console.ReadLine() ?? "0");
//    Console.Write("nhap chieu dai: ");
//    dai = float.Parse(Console.ReadLine() ?? "0");

//    if (rong <= 0 || dai <= 0)
//        throw new Exception("Do dai phai lon hon 0");

//    Console.WriteLine($"Dien tich hinh chu nhat la: {rong * dai}");
//}
//catch (FormatException ex)
//{
//    Console.WriteLine("loi nhap lieu "+ ex.Message);
//}
//catch (Exception ex)
//{
//    Console.WriteLine("loi " + ex);
//}

//// bài 3
//int doC;
//float doF;
//doC = int.Parse(Console.ReadLine() ?? "0");
//doF = (doC * 9/5 ) + 32;

////bài 4
//int soNguyen;
//soNguyen = int.Parse(Console.ReadLine() ?? "0");
//if (soNguyen % 2 == 0)
//{
//    Console.WriteLine($"{soNguyen} la so chan");
//}
//else
//{
//    Console.WriteLine($"{soNguyen} la so le");
//}

////bài 5
//int a, b, tong, tich;
//Console.Write("nhap so a: ");
//a = int.Parse(Console.ReadLine() ?? "0");
//Console.Write("nhap so b: ");
//b = int.Parse(Console.ReadLine() ?? "0");
//tong = a + b;
//tich = a * b;
//Console.WriteLine("tong 2 so la: " + tong);
//Console.WriteLine("tich 2 so la: " + tich);

//// bai 6
//int x;
//Console.Write("nhap so ");
//x = int.Parse(Console.ReadLine() ?? "0");
//if (x > 0)
//{
//    Console.WriteLine($"{x} la so nguyen duong");
//}
//else if (x < 0)
//{
//    Console.WriteLine($"{x} la so nguyen am");
//}
//else
//{
//    Console.WriteLine($"{x} ko phai so nguyen duong hay nguyen am");
//}

////bai 7
//int nam;
//Console.Write("nhap nam bat ki: ");
//nam = int.Parse(Console.ReadLine() ?? "0");
//if (nam % 4 == 0 && nam % 100 != 0)
//{
//    Console.WriteLine($"nam {nam} la nam nhuan");
//}
//else
//{
//    Console.WriteLine($" nam {nam} khong phai la nam nhuan");
//}

////bài 8
//for (int i = 1; i <= 10; i++)
//{
//    for (int j = 1; j <= 10; j++)
//    {
//        Console.WriteLine($"{i} * {j} = {i * j}");
//    }
//    Console.WriteLine();
//}

////bai 9
//int n;
//Console.Write("nhap so nguyen");
//n = int.Parse(Console.ReadLine() ?? "0");

//long giaiThua = 1;
//for (int i = 1; i<=n; i++)
//{
//    giaiThua *= i;
//}
//Console.WriteLine($"giai thua cua so {n} la: {giaiThua}");

////bài 10
//int so, dem=0;
//Console.WriteLine("nhap so tu nhien: ");
//so = int.Parse(Console.ReadLine() ?? "0");

//for (int i = 1; i < so; i++)
//{
//    if (so % i == 0){
//        dem++;
//    }
//}
//if (dem == 1)
//{
//    Console.WriteLine($"{so} la so nguyen to");
//}
//else
//{
//    Console.WriteLine($"{so} khong phai la so nguyen to");
//}