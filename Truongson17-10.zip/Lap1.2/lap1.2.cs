﻿//// bai 1
//int[] arr = {1, 2, 3, 4, 6};
//Console.WriteLine("tong cac so chan trong mang la " + tongSoChan(arr));
//static int tongSoChan(int[] arr)
//{
//    int Tong = 0;
//    for (int i = 0; i < arr.Length; i++)
//    {
//        if (arr[i] % 2 == 0)
//        {
//            Tong += arr[i];
//        }
//    }
//    return Tong;
//}

//// bai 2
//int n;
//n = int.Parse(Console.ReadLine() ?? "0");
//int[] a =  new int[n];

//for (int i = 0; i < n; i++)
//{
//    a[i] = int.Parse(Console.ReadLine() ?? "0");
//}
//for (int i = 0; i < n; i++)
//{
//    kiemTraNT(a[i]);
//}
//static void kiemTraNT(int a){
//    int dem = 0;
//    for (int i = 1; i < a; i++)
//    {
//        if (a >= 2 && a % i == 0)
//        {
//            dem += 1;
//        }
//    }
//    if (dem == 1)
//    {
//        Console.WriteLine($"{a} la so nguyen to");
//    }
//    else
//    {
//        Console.WriteLine($"{a} khong phai la so nguyen to");
//    }

//}

//// bai 3
//int n, demAm = 0 , demDuong = 0;
//n = int.Parse(Console.ReadLine() ?? "0");
//int[] a = new int[n];

//for (int i = 0; i < n; i++)
//{
//    a[i] = int.Parse(Console.ReadLine() ?? "0");
//}
//for (int i = 0; i < n; i++)
//{
//    if (kiemTraAmDuong(a[i]))
//    {
//        demDuong++;
//    }
//    else 
//    {
//        demAm++;
//    }
//}
//static bool kiemTraAmDuong(int a)
//{
//    if (a >= 0)
//    {
//        return true;
//    }
//    else
//    {
//        return false;
//    }
//}


////bai 4
//int[] arr = { 1, 2, 3, 4, 6 };
//Console.WriteLine($" so lon thu 2 trong mang la: {timSoLonThu2(arr)}");
//static int timSoLonThu2(int[] arr)
//{
//    int doi;
//    for (int i = 0; i < arr.Length; i++)
//    {
//        for (int j = i + 1; j < arr.Length; j++)
//        {
//            if (arr[i] < arr[j])
//            {
//                doi=arr[i];
//                arr[i]=arr[j];
//                arr[j]=doi;
//            }
//        }
//    }
//    return arr[1];

//}

//// bai 5
//int a, b;
//Console.Write("nhap so a: ");
//a= int.Parse(Console.ReadLine() ?? "0");
//Console.Write("nhap so b: ");
//b = int.Parse(Console.ReadLine() ?? "0");
//hoanVi(a, b);

//static void hoanVi(int a, int b)
//{
//    int c = a;
//    a = b;
//    b = c;

//    Console.WriteLine($"so a va b sau khi hoan vi la: a = {a}, b = {b}");
//}

//// bai 6 
//int n;
//Console.WriteLine("do dai cua mang: ");
//n = int.Parse(Console.ReadLine() ?? "0");
//int[] arr = new int[n];
//for (int i = 0; i < arr.Length; i++)
//{
//    Console.Write($"so thu {i+1} = ");
//    arr[i] = int.Parse(Console.ReadLine() ?? "0");
//}
//Console.WriteLine($"mang sau khi xap sep: ");
//sapXepMnang(arr);
//for (int i = 0;i < arr.Length; i++)
//{
//    Console.Write(arr[i]+" ");
//}

//static Array sapXepMnang(int[] arr)
//{
//    int doi;
//    for (int i = 0; i < arr.Length; i++)
//    {
//        for (int j = i + 1; j < arr.Length; j++)
//        {
//            if (arr[i] > arr[j])
//            {
//                doi = arr[i];
//                arr[i] = arr[j];
//                arr[j] = doi;
//            }
            
//        }
//    }
//    return arr;
//}