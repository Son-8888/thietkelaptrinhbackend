﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace lap1._3
{
    internal class Bao : TaiLieu
    {
        private DateOnly ngayPH;
        
        public Bao() { }

        public Bao(string maTL, string tenNXB, int soBan, DateOnly NgayPH) : base(maTL, tenNXB, soBan)
        {
            this.ngayPH = NgayPH;
        }
        public override void Nhap()
        {
            
            try
            {
                base.Nhap();
                Console.Write(" + ngay phat hanh: ");
                ngayPH = DateOnly.Parse(Console.ReadLine() ?? "0");
            }
            catch (FormatException ex)
            {
                Console.WriteLine("loi nhap lieu: " + ex.Message);
            }
            catch (Exception ex)
            {

                Console.WriteLine("loi " + ex);
            }
        }
        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($" + ngay phat hanh: {ngayPH}");
        }
    }
}
