﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace lap1._3
{
    internal class QuanLyTL 
    {
        private List<TaiLieu> danhSachTaiLieu = new List<TaiLieu>();

        public void NhapTTTL()
        {
            char loaiTL;
            Console.Write("chon lai tai lieu: 1.sach / 2.tap chi / 3.bao");
            loaiTL = char.Parse(Console.ReadLine() ?? "0");

            switch (loaiTL)
            {
                case '1':
                    Sach sach = new Sach();
                    sach.Nhap();
                    danhSachTaiLieu.Add(sach);
                    break;
                case '2':
                    TapChi tapChi = new TapChi();
                    tapChi.Nhap();
                    danhSachTaiLieu.Add(tapChi);
                    break;
                case '3':
                    Bao bao = new Bao();
                    bao.Nhap();
                    danhSachTaiLieu.Add(bao);
                    break;
                default:
                    Console.WriteLine("khong co lua chon nay");
                    break;
            }
        }
        public void HienThiTTTL()
        {
            Console.WriteLine("-- danh sach tai lieu --");
            for (int i = 0; i < danhSachTaiLieu.Count; i++)
            {
                danhSachTaiLieu[i].Xuat();
                Console.WriteLine("--------------------");
            }
        }
        public void TimKiemTLTheoLoai()
        {
            Console.Write("chon loai tai lieu muon tim");
            Console.WriteLine("1. sach");
            Console.WriteLine("2. tap chi");
            Console.WriteLine("3. bao");
            char loai = char.Parse(Console.ReadLine() ?? "1");
            foreach (var tl in danhSachTaiLieu)
            {
                switch (loai)
                {
                    case '1':
                        if (tl is Sach)
                        {
                            tl.Xuat();
                        }
                        break;

                    case '2':
                        if (tl is TapChi)
                        {
                            tl.Xuat();
                        }
                        break;

                    case '3':
                        if (tl is Bao)
                        {
                            tl.Xuat();
                        }
                        break;
                    default:
                        Console.WriteLine("ban phai chon tu 1-3");
                        break;
                }

            }

        }


        public static void Main(string[] args)
        {
            QuanLyTL quanLy = new QuanLyTL();

            bool tiepTuc = true;
            while (tiepTuc)
            {
                Console.WriteLine("\n====== MENU ======");
                Console.WriteLine("1: nhap thong tin tai lieu.");
                Console.WriteLine("2: hien thi thong tin tai lieu.");
                Console.WriteLine("3: tim kiem tai lieu theo loai.");
                Console.WriteLine("4: thoat.");
                Console.Write("nhap so (1-4): ");
                char chon = char.Parse(Console.ReadLine() ?? "0");

                switch (chon)
                {
                    case '1':
                        quanLy.NhapTTTL();
                        break;
                    case '2':
                        quanLy.HienThiTTTL();
                        break;
                    case '3':
                        quanLy.TimKiemTLTheoLoai();
                        break;
                    case '4':
                        tiepTuc = false;
                        break;
                    default:
                        Console.WriteLine("vui long chon 1 - 4.");
                        break;
                }
            }
        }

    }
}
