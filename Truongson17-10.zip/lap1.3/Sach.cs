﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace lap1._3
{
    internal class Sach : TaiLieu
    {
        private string? tenTacGia;
        private int soTrang;

        // khoi tao ko tham so
        public Sach() { }

        // khoi tao co tham so
        public Sach(string maTL, string tenNXB, int soBan, string? tenTacGia, int soTrang) : base(maTL, tenNXB, soBan)
        {
            this.tenTacGia = tenTacGia;
            this.soTrang = soTrang;
        }

        //nhap tt sach
        public override void Nhap()
        {
            try
            {
                base.Nhap();
                Console.Write(" + ten tac gia: ");
                tenTacGia = Console.ReadLine();
                Console.Write(" + So trang: ");
                soTrang = int.Parse(Console.ReadLine() ?? "0");
                if (soTrang < 0) {
                    throw new Exception("so trng khong dươc nho hon 0");
                }
            }
            catch (FormatException ex){
                Console.WriteLine("loi nhap lieu: " + ex.Message);
            }
            catch (Exception ex)
            {

                Console.WriteLine("loi " + ex);
            }
            
        }
        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($" + Ten tac gia: {tenTacGia}");
            Console.WriteLine($" + So trang: {soTrang}");
        }
    }
}
