﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lap1._3
{
    internal class TaiLieu
    {
        protected string? maTL;
        protected string? tenNXB;
        protected int soBan;
        //phuong thu khoi tao mac dinh
        public TaiLieu() { }

        //phuong thuc khoi tao co tham so
        public TaiLieu(string? maTL, string? tenNXB, int soBan)
        {
            this.maTL = maTL;
            this.tenNXB = tenNXB;
            this.soBan = soBan;
        }
        // nhap thong tin tai lieu
        public virtual void Nhap()
        {
            try
            {
                Console.Write(" + ma tai lieu: ");
                maTL = Console.ReadLine();
                Console.Write(" + ten nha xuat ban: ");
                tenNXB = Console.ReadLine();
                Console.Write(" + So ban phat hanh: ");
                soBan = int.Parse(Console.ReadLine() ?? "0");
                if (soBan < 0) {
                    throw new Exception("so ban khong duoc nho hon 0");
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine("loi nhap lieu: " + ex.Message);
            }
            catch (Exception ex)
            {

                Console.WriteLine("loi " + ex);
            }
        }
        public virtual void Xuat()
        {
            Console.WriteLine($" + Ma tai lieu: {maTL}");
            Console.WriteLine($" + Ten nha xuat ban: {tenNXB}");
            Console.WriteLine($" + So Ban phat hanh: {soBan}");
        }
        
    }
}
