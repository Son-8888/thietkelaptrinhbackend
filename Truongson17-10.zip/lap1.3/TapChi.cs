﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lap1._3
{
    internal class TapChi : TaiLieu
    {
        private int SoPH;
        private int thangPH;

        public TapChi() { }

        public TapChi(string maTL, string tenNXB, int soBan, int soPH, int thangPH) : base(maTL, tenNXB, soBan)
        {
            this.SoPH = soPH;
            this.thangPH = thangPH;
        }

        public override void Nhap()
        {
            
            try
            {
                base.Nhap();
                Console.Write(" + so phat hanh: ");
                SoPH = int.Parse(Console.ReadLine() ?? "0");
                Console.Write(" + thang phat hanh: ");
                thangPH = int.Parse(Console.ReadLine() ?? "0");
                if (thangPH > 12) {
                    throw new Exception("khong co thang lon hon 12 va nho hon 0");
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine("loi nhap lieu: " + ex.Message);
            }
            catch (Exception ex)
            {

                Console.WriteLine("loi " + ex);
            }
        }
        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($" + so phat hanh: {SoPH}");
            Console.WriteLine($" + thang phat hanh: {thangPH}");
        }
    }
}
